# rakamin-java
<b>Learning  Automation Testing web <br>
Website: https://saucedemo.com/ <br> 
Framework : Java Gherkin Cucumber </b> <br>
by:muhammad edi cahyono <br> <br>

The following are the features that we automate with the framework. We have attached a screenshot in the Google Drive link.
The summary home report :
![Capture-home](https://github.com/medicahyono/rakamin-java/assets/148028751/d7bad6a2-52fa-462f-8e50-a1403d252cbf)

Feature Login <br>
	Scenario:Success Login<br>
	Scenario:Failed Logins with invalid password<br>
	Scenario:Failed Logins with invalid username<br>
   https://drive.google.com/file/d/1y_BqPR5qtybW0WTPHB1XWYtdOu4ZgiUr/view?usp=sharing<br><br>
	
Feature:Logout Page Saucedemo<br>
	Scenario:Success Logout<br>
   https://drive.google.com/file/d/1Ln9oIRIgS5-nSOgJfpXuqC1Nfe1OI9nR/view?usp=sharing<br><br>

Feature:Shoping Product<br>
	Scenario:Success add product<br>
	Scenario:Success delete product in cart<br>
   https://drive.google.com/file/d/1dHGEWENB3jlohNW5y0U7kBWNmjSEyf_m/view?usp=sharing<br><br>

Feature:Payment saucedemo<br>
	Scenario:Success checkout<br>
   https://drive.google.com/file/d/1neoxnnsRuX9qXgBBYyawa-szsDBMQ77Z/view?usp=sharing<br><br>



 

	
