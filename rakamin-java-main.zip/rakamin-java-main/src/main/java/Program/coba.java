package Program;

import javax.swing.*;

public class coba
{
    public static void main (String []arg)
    {
        //ini adalah program untuk mencetak hello word
        System.out.println("hello, World");
        System.out.println("hello, medicahyono");
        System.out.println("hello, kholifah");
        System.out.println("hello, taqy");

        JOptionPane.showMessageDialog(null,"Hay Medic, Kholif dan Taqy");
        JOptionPane.showConfirmDialog(null,"kamu yakin mau lanjut ?");
    }
}
